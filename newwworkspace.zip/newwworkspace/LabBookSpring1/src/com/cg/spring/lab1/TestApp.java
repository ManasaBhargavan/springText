package com.cg.spring.lab1;

import org.springframework.context.support.ClassPathXmlApplicationContext;


public class TestApp {

	public static void main(String[] args) {
		ClassPathXmlApplicationContext ctx=new ClassPathXmlApplicationContext("applicationContext.xml");
		Employee obj=(Employee) ctx.getBean("employee");
		obj.display();
		
 
	}

}
