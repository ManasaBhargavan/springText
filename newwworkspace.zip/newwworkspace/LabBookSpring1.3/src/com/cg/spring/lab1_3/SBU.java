package com.cg.spring.lab1_3;

import java.util.List;

public class SBU {

	private int sbuID;
	private String sbuHead;
	private String sbuName;
	private List<Employee> employees;
	public int getSbuID() {
		return sbuID;
	}
	public void setSbuID(int sbuID) {
		this.sbuID = sbuID;
	}
	public String getSbuHead() {
		return sbuHead;
	}
	public void setSbuHead(String sbuHead) {
		this.sbuHead = sbuHead;
	}
	public String getSbuName() {
		return sbuName;
	}
	public void setSbuName(String sbuName) {
		this.sbuName = sbuName;
	}
	public List<Employee> getEmployees() {
		return employees;
	}
	public void setEmployees(List<Employee> employees) {
		this.employees = employees;
	}
	public void display(){
		System.out.println("SBU Details");
		System.out.println("-------------------------");
		System.out.println("SBU [sbuID=" + sbuID + ", sbuHead=" + sbuHead + ", sbuName="
				+ sbuName + "]");
		System.out.println("Employee Details");
		System.out.println("-------------------------");
		for(Employee e : employees){
			System.out.println("Employee [empAge="+e.getAge()+",empId="+e.getEmpId()+",empName="+e.getEmpName()+",empSalary="+e.getEmpSalary()+"]");
		}
		
		
	}
	
	
}
