package com.cg.spring.lab1_3;

public class Employee {
	private int age;
	private int empId;
	private String empName;
	private double empSalary;
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public double getEmpSalary() {
		return empSalary;
	}
	public void setEmpSalary(double empSalary) {
		this.empSalary = empSalary;
	}
	@Override
	public String toString() {
		return "Employee [age=" + age + ", empId=" + empId + ", empName="
				+ empName + ", empSalary=" + empSalary + "]";
	}
	
}
