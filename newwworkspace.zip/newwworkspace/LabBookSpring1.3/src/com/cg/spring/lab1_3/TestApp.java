package com.cg.spring.lab1_3;

import org.springframework.context.support.ClassPathXmlApplicationContext;


public class TestApp {

	public static void main(String[] args) {
		ClassPathXmlApplicationContext ctx=new ClassPathXmlApplicationContext("applicationContext.xml");
		SBU obj=(SBU) ctx.getBean("sbu");
		obj.display();
		
 
	}

}
