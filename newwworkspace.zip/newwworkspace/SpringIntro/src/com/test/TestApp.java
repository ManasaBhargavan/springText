package com.test;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestApp {

	public static void main(String[] args) {
		
		ClassPathXmlApplicationContext ctx=new ClassPathXmlApplicationContext("Spring2.xml");
		Triangle obj=(Triangle) ctx.getBean("triangle");
		obj.draw();
		
        ctx.close();


	}

}
