package com.cg.entities;

public class Employee {

}
