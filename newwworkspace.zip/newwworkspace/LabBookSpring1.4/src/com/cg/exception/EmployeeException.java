package com.cg.exception;

public class EmployeeException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2898889531182648155L;

	public EmployeeException(String message) {
		super(message);
		
	}
	
}
