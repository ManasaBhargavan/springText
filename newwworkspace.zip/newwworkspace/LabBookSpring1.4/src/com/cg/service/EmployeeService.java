package com.cg.service;

public class EmployeeService implements IEmployeeService {

}
