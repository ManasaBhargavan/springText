package com.cg.dao;

public class EmployeeDao implements IEmployeeDao {

}
